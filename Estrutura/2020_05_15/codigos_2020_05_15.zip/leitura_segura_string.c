char nome[41]; // garante nome com até 40 + '\0'
char c, int i =0;
//leitura de strings utilizando expressões regulares
scanf ("%40[^'\n']", nome); //para no limite ou no <enter>

scanf ("%10['a'-'z']", nome);

//leitura de strings caracter a caracter
while ((c = getchar()) != '\n' && i<40) {
	nome[i++] = c;
}
nome[i] = '\0';

