typedef struct aluno {
	int matricula;
	float n1;
} s_aluno;

struct aluno turma[5];
s_aluno turma2[10];
int i, pos_maior_n1;
float media_n1, maior_n1;
for (i=0; i<5; i++) {
	scanf ("%d%f", &turma[i].matricula, &turma[i].n1);
}
maior_n1 = turma[0].n1;
pos_maior_n1 = 0;
media_n1 = turma[0].n1;
for (i=1; i<5;i++) {
	//acumular a soma
	media_n1 = media_n1 + turma[i].n1;
	//verificar se o próximo elemento é maior que maior_n1
	if (turma[i].n1 > maior_n1) {
		maior_n1 = turma[i].n1;
		pos_maior_n1 = i;
	}
}
media_n1 = media_n1 / 5;
printf ("media n1 = %.2f\n", media_n1);
printf ("maior_n1 = %.2f e eh do aluno %d\n", maior_n1, turma[pos_maior_n1].matricula);
