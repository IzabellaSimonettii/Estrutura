#include <stdio.h>

typedef struct {
	int dados[10];
	int topo;
} pilha;
void inicia_pilha (pilha *p) {
	p->topo = 0;
}
int pilha_vazia (pilha *p) {
	if (p->topo == 0)
		return 1;
	else 
	    return 0;
	//return !p->topo;
}
int pilha_cheia (pilha *p) {
	if (p->topo == 10)
		return 1;
	else 
	    return 0;
	//return p->topo == 10;
}
void push (int e, pilha *p) {
	p->dados[p->topo++] = e;
}
int pop (pilha *p){ 
    int i;
    p->topo--;
    i = p->dados[p->topo];
	return i;
	//return p->dados[--p->topo];
}
int main() {
	pilha p1; 
	inicia_pilha(&p1);
	if (pilha_vazia(&p1)) {
		printf ("pilha inicializada com sucesso, esta vazia\n");
	}
	else {
		printf ("Huston, we have a problem...\n");
	}
	if (pilha_cheia(&p1)) {
		printf ("stack overflow\n");
	}
	else {
		push (3, &p1);
	}
	if (pilha_vazia(&p1)) {
		printf ("pilha vazia\n");
	}
	else {
		printf ("%d foi desempilhado\n", pop(&p1));
	}
	return 0;
}