#include <stdio.h>
#include <stdlib.h>

int main () {
	int size;
	int v[size]; /* definido em tempo de compila��o*/
	int *p;
	printf ("\nsize: %d\n", size); //typo
	scanf ("%d", &size);
	p = (int*) malloc (size * sizeof(int));
	return 0;
}
