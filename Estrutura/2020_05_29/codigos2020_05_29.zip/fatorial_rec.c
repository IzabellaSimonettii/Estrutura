#include <stdio.h>

int fat_rec (int n) {
	if (n==0 || n==1)
		return 1;
	return n*fat_rec(n-1);
}
int main () {
	printf ("fatorial de 5 = %d", fat_rec(5));
	return 0;
}
